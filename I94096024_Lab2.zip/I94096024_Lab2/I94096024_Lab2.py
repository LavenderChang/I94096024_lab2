import pygame
import time

#to check working directory
import os
print(os.listdir("images"))

WIN_WIDTH = 1024
WIN_HEIGHT = 600
BTN_WIDTH = 80
BTN_HEIGHT = 80
HP_WIDTH = 40
HP_HEIGHT = 40
FPS = 30

# color (RGB)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)


# load image (background, enemy, buttons)
# use pygame.transform.scale(file, (width, height)) to modify the size
background_image = pygame.transform.scale(pygame.image.load("images/Map.png"), (WIN_WIDTH, WIN_HEIGHT))
enemy_image = pygame.transform.scale(pygame.image.load("images/enemy.png"), (100, 100))
hp_image = pygame.transform.scale(pygame.image.load("images/hp.png"), (50, 50))
hp_gray_image = pygame.transform.scale(pygame.image.load("images/hp_gray.png"), (50, 50))
muse_image = pygame.transform.scale(pygame.image.load("images/muse.png"), (100, 100))
pause_image = pygame.transform.scale(pygame.image.load("images/pause.png"), (100, 100))
continue_image = pygame.transform.scale(pygame.image.load("images/continue.png"), (100, 100))
sound_image = pygame.transform.scale(pygame.image.load("images/sound.png"), (100, 100))

# set the title
pygame.display.set_caption("My first game")

class Game:
    def __init__(self):
        # initialization
        pygame.init()
        # window
        self.win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        # to be more interactive, hp should be variable
        #...(to be done)

        # but we set the initial hp to test
        self.hp = 7
        self.max_hp = 10
        pass

    def game_run(self):
        # game loop

        # set the clock to unify different fps(frame per second) on different devices

        clock = pygame.time.Clock()
        run = True
        while run:
            clock.tick(FPS)
            # event loop (user action)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
            #draw background
            self.win.blit(background_image, (0, 0))
            #draw enemy and health bar
            self.win.blit(enemy_image, (0, 230))
            #                     (r, g, b), [x, y, length, height]
            pygame.draw.rect(self.win, (255, 0, 0), [10, 200, 80, 10])
            # draw menu and buttons
            pygame.draw.rect(self.win, (0, 0, 0), [0, 0, 1024, 100])
            self.win.blit(muse_image, (600, 10))
            self.win.blit(sound_image,(700, 10))
            self.win.blit(continue_image, (800, 10))
            self.win.blit(pause_image, (900, 10))
            # draw health bar
            # be careful! we can read in self.(value) easily, but do not modify them easily
            # the better strategy is to set new variables to use in while, for,... loops
            for i in range(0, 5):
                self.win.blit(hp_gray_image, (300 + (i*50), 10))
            for i in range(5, 10):
                self.win.blit(hp_gray_image, (300 + ((i-5)*50), 50))
            if self.hp > 5:
                for i in range(0, 5):
                    self.win.blit(hp_image,(300+(i*50), 10))
                for hp in range(5, self.hp):
                    self.win.blit(hp_image,(300+((hp-5)*50), 50))
            else:
                for hp in range(0, self.hp):
                    self.win.blit(hp_image, (300 + (hp*50), 10))

            # draw time
            # ...(to be done)

            pygame.display.update()

if __name__ == "__main__":
    covid_game = Game()
    covid_game.game_run()
